module.exports = {
  plugins: [require("postcss-nesting")],
};
